import java.util.ArrayList;
import java.util.List;

public abstract class Account {
    public static final String CHECKING = "CHECKING";
    public static final String SAVINGS = "SAVINGS";
    protected long accountNumber;
    protected double balance;
    protected List<Transaction> transactionList;

    public Account() {
        this.accountNumber = -1;
        this.balance = 0;
    }

    public Account(long accountNumber, double balance) {
        this.accountNumber = accountNumber;
        this.balance = balance;
        this.transactionList = new ArrayList<>();
    }

    public String getTransactionHistory() {
        StringBuilder result = new StringBuilder();
        if (transactionList != null) {
            result.append("Lịch sử giao dịch của tài khoản " + accountNumber + ":\n");
            for (Transaction transaction : transactionList) {
                result.append(transaction.getTransactionSummary(transaction.getType()));
            }
        }
        return result.toString();
    }

    public void addTransaction(Transaction transaction) {
        this.transactionList.add(transaction);
    }

    public abstract void deposit(double amount);

    public abstract void withdraw(double amount);

    public void doWithdrawing(double amount) throws InsufficientFundsException, InvalidFundingAmountException {
        try {
            if (amount > 1000.0) {
                throw new IllegalArgumentException("Illegal amount");
            }
        } catch (IllegalArgumentException e) {
            System.out.println(e.getMessage());
            return;
        }

        try {
            if (this.balance < 5000.0) {
                throw new InsufficientFundsException();
            }
        } catch (InsufficientFundsException e) {
            System.out.println(e.getMessage());
            return;
        }
        if (amount <= 0) {
            throw new InvalidFundingAmountException(amount);
        } else if (amount > balance) {
            throw new InsufficientFundsException(amount);
        } else {
            balance -= amount;
        }

    }


    public void doDepositing(double amount) throws InvalidFundingAmountException {
        if (amount <= 0) {
            throw new InvalidFundingAmountException(amount);
        } else {
            balance += amount;
        }
    }

    @Override
    public boolean equals(Object o) {
        if (o instanceof Account) {
            Account a = (Account) o;
            return this.accountNumber == ((Account) o).getAccountNumber() ;
        }
        return false;
    }

    public double getBalance() {
        return balance;
    }

    public void setBalance(double balance) {
        this.balance = balance;
    }

    public long getAccountNumber() {
        return accountNumber;
    }

    public void setAccountNumber(long accountNumber) {
        this.accountNumber = accountNumber;
    }
}
