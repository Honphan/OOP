
public class SavingsAccount extends Account {

    public SavingsAccount(long accountNumber, double balance) {
        super(accountNumber, balance);
    }
    public SavingsAccount() {
        super();
    }

    public void withdraw(double amount) {
        double initialBalance = this.balance;
        try {
            doWithdrawing(amount);
        } catch (InvalidFundingAmountException
                 | InsufficientFundsException e) {
            System.out.println(e.getMessage());
            return;
        }

        this.transactionList.add(new Transaction(
                Transaction.TYPE_WITHDRAW_SAVINGS,
                amount,
                initialBalance,
                this.balance)
        );
    }

    /**
     * Deposit
     */
    public void deposit(double amount) {
        double initialBalance = this.balance;
        try {
            doDepositing(amount);
        } catch (InvalidFundingAmountException e) {
            System.out.println(e.getMessage());
            return;
        }

        this.transactionList.add(new Transaction(
                Transaction.TYPE_DEPOSIT_SAVINGS,
                amount,
                initialBalance,
                this.balance)
        );
    }
}
